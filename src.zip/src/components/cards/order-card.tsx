"use client";

import { ProductCard } from "@/components/cards/product-card";
import { Button } from "@/components/ui/button";

export type OrderRole = "buyer" | "seller";
export type OrderStatus = "in_progress" | "delivered" | "cancelled";

interface OrderCardProps {
    id: string; // identifiant de la commande
    title: string;
    price: number;
    location?: string;
    counterpartName: string; // nom de l’autre partie (vendeur ou acheteur)
    date: string;
    status: OrderStatus;
    role: OrderRole; // "buyer" => vous êtes l’acheteur, "seller" => vous êtes le vendeur
}

/**
 * Carte compacte pour les commandes (achats / ventes).
 * Utilisée comme base pour :
 * - Mes achats (role="buyer")
 * - Mes ventes (role="seller")
 */
export function OrderCard({
                              id,
                              title,
                              price,
                              location,
                              counterpartName,
                              date,
                              status,
                              role,
                          }: OrderCardProps) {
    const counterpartLabel = role === "buyer" ? "Vendeur" : "Acheteur";

    const statusLabel =
        status === "delivered"
            ? "Livré"
            : status === "cancelled"
                ? "Annulé"
                : "En cours";

    const handleTrackOrder = () => {
        alert("Simulation : suivi de la commande.");
    };

    return (
        <ProductCard
            id={id}
            title={title}
            price={price}
            location={location}
            subtitle={`${counterpartLabel} : ${counterpartName}`}
            href={`/orders/${id}`} // clic sur la carte → détail de commande
            footer={
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-muted-foreground">
            Statut : {statusLabel} • {date}
          </span>

                    {status === "in_progress" && (
                        <Button
                            type="button"
                            variant="link"
                            size="sm"
                            className="px-0 text-xs"
                            onClick={handleTrackOrder}
                        >
                            Suivre la commande
                        </Button>
                    )}
                </div>
            }
        />
    );
}